var detail = [];
var keys = [];
var id = 0;
var flag = 0;
function run() {
  var file = document.getElementById("filechoice").files[0];
  if (file) {
    var reader = new FileReader();
    reader.readAsText(file, "UTF-8");
    reader.onload = function (evt) {
      var csv = evt.target.result;
      detail = $.csv.toObjects(csv);
      console.log(detail);
    }
    reader.onerror = function (evt) {
      alert("error reading file");
    }
  }
}
function blankspaceValidate(value) {
  if (value.length < 1) {
    return " cannot be empty";
  }
}
function checkValue(id, keys) {
  flag = 0;
  question = document.getElementById('question').value;
  if (blankspaceValidate(question)) {
    $("#Data_alert").text("Question " + blankspaceValidate(question));
    $("#Data_alert").show();
  } else {
    for (i = 0; i < keys.length; i++) {
      if ((new RegExp(keys[i], 'i')).test(question)) {
        flag = 1;
        var k = keys[i];
        document.getElementById('Data_alert').innerHTML = " ";
        document.getElementById('result').innerHTML = detail[id]["name"] + "'s favourite " + k + " is " + detail[id][k];
      }
      else {
        document.getElementById('result').innerHTML = " ";
        document.getElementById('Data_alert').innerHTML = "Insufficient data";
      }
      if (flag == 1) {
        break;
      }
    }
  }
}
$(document).ready(function () {
  $("#reset").blur(function () {
    document.getElementById('Data_alert').innerHTML = " ";
    document.getElementById('result').innerHTML = " ";
    document.getElementById('Name_alert').innerHTML = " ";
    document.getElementById('question').value = " ";
  });
  $('#name').blur(function () {
    flag = 0;
    4
    var name = this.value;
    $("#Name_alert").hide();
    if (blankspaceValidate(name)) {
      $("#Name_alert").text("Name " + blankspaceValidate(name));
      $("#Name_alert").show();
    } else {
      for (i = 0; i < detail.length; i++) {
        if ((new RegExp(detail[i].name, 'i')).test(name) == true) {
          flag = 1;
          //alert(i);
          $('#Name_alert').text(" ");
          id = i;
          keys = Object.getOwnPropertyNames(detail[i]);
        }
        else if ((new RegExp(detail[i].name, 'i')).test(name) == false) {
          $('#result').text(" ");
          $('#Name_alert').text("Name Not Found Add new User");
          $("#Name_alert").show();
        }
        if (flag == 1) {
          break;
        }
      }
    }
  });
  $("#find").click(function () {
    checkValue(id, keys)
  });
});
